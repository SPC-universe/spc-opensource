
//$('.container').hide();

var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');

        //$('.container').show();
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
    },
    findDevices: function() {
        SPCFit.findDevices(function(deviceList) {
            $('#deviceList').html('');
            for(var i in deviceList) {
                $('#deviceList').append('<p><button onclick="app.connect(\'' + deviceList[i] + '\')" class="btn btn-100 btn-primary">connect(\'' + deviceList[i] + '\')</button></p>');
            }
        });
    },
    connect: function(deviceId) {
        SPCFit.connect(deviceId, function() {
            alert('connected');
        });
    },
    setTime: function() {
        var time = $('#timeResponse').val();

        SPCFit.setTime(time, function(success) {

        }, function(error) {
            alert(error);
        });
    },
    getTime: function() {
        SPCFit.getTime(function(time) {
            $('#timeResponse').val(time);
        });
    },
    setPersonalInformation: function() {
        var info = JSON.parse($('#personResponse').val());

        SPCFit.setPersonalInformation(info);
    },
    getPersonalInformation: function() {
        SPCFit.getPersonalInformation(function(info) {
            $('#personResponse').val(JSON.stringify(info));
        });
    },
    setTargetSteps: function() {
        var targetSteps = parseInt($('#targetSteps').val(), 10);

        SPCFit.setTargetSteps(targetSteps);
    },
    getTargetSteps: function() {
        SPCFit.getTargetSteps(function(targetSteps) {
            $('#targetSteps').val(targetSteps);
        });
    },
    getCurrentActivityInformation: function() {
        SPCFit.getCurrentActivityInformation(function(activity) {
            $('#activityResponse').val(JSON.stringify(activity));
        });
    },
    getTotalActivityData: function() {
        var day = parseInt($('#day').val());

        SPCFit.getTotalActivityData(day, function(activity) {
            $('#activityResponse').val(JSON.stringify(activity));
        });
    },
    getDetailActivityData: function() {
        var day = parseInt($('#day').val());

        SPCFit.getDetailActivityData(day, function(activity) {
            $('#activityResponse').val(JSON.stringify(activity));
        });
    },
    realtimeResponse: function(activity) {
        $('#realtimeResponse').val(JSON.stringify(activity));
    },
    startRealTimeMeterMode: function() {
        SPCFit.startRealTimeMeterMode('app.realtimeResponse');
    },
    stopRealTimeMeterMode: function() {
        SPCFit.stopRealTimeMeterMode();
    }
};

app.initialize();
