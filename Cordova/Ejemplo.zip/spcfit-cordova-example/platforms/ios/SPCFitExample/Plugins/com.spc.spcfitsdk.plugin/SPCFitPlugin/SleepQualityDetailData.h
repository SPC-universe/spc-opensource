#import <Foundation/Foundation.h>

@interface SleepQualityDetailData : NSObject

@property (strong, nonatomic) NSDate *date;
@property (nonatomic) int quality;

@end
