cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/cordova-plugin-whitelist/whitelist.js",
        "id": "cordova-plugin-whitelist.whitelist",
        "runs": true
    },
    {
        "file": "plugins/com.spc.spcfitsdk.plugin/www/SPCFit.js",
        "id": "com.spc.spcfitsdk.plugin.SPCFit",
        "clobbers": [
            "SPCFit"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-whitelist": "1.0.0",
    "com.spc.spcfitsdk.plugin": "0.0.5"
}
// BOTTOM OF METADATA
});